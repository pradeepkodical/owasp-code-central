using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Collections;
using System.IO;


namespace Owasp.SiteGenerator
{
    class GlobalVariables
    {
        /// <summary>
        /// ASCX Mappings
        /// </summary>                  
        //public static TextBox   ascx_Admin_txtDebugAllReceivedMessages;
    }
}

