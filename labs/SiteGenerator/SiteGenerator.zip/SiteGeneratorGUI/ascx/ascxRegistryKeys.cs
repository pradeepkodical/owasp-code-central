using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace Owasp.SiteGenerator.ascx
{
    public partial class ascxRegistryKeys : UserControl
    {
        public ascxRegistryKeys()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
