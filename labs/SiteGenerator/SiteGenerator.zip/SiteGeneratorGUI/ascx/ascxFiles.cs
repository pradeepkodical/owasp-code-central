using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace Owasp.SiteGenerator.ascx
{
    public partial class ascxFiles : UserControl
    {
        public ascxFiles()
        {
            InitializeComponent();
        }
    }
}
