This file was downloaded or bought from www.adrianTNT.com

Cromas menu XML
--------------------
How to use the menu:
--------------------
First extract all the files from this archive in the same directory, then you can open the 
html page to see how the menu looks like.
The menu is a flash file (swf) that can be included in a html document and act as a menu,
all you need is to edit the xml file that is next to the menu, open the xml file with a text
editor like wordpad or notepad and change the parameters inside the "" signs to change
the buttons text, url to open and url target frame, if you do not know what a parameter is,
do not edit it.
You can have upto 15 buttons, to hide a button enter "none" as the button text in the 
XML file.
To change the color configuration you have to edit the last line of the XML file, and enter 
the RGB value without the "#" sign, for example: 

white is "ffffff" 
black is "000000"
blue is  "0000ff"
red is   "ff0000"
green is "009900"

In the last line you hsve the option to change the default mouse cursor, if you enter
custom_cursor="true" than you will use the menu`s custom cursor, if you do not want it enter
custom_cursor="false" and you will have the default cursor.
It`s easy to use, just like any menu from adrianTNT.com


For any questions or comments please send e-mail to adrianTNT@adrianTNT.com
or wisit http://www.adriantnt.com

Flash menus, buttons, components, sounds, libraries, extensions, web design and hosting services:
http://www.adriantnt.com

web design services, search engine optimizations and hosting services:
http://www.symbioticdesign.com